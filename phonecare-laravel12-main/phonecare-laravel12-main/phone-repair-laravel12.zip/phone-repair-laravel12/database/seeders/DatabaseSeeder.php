<?php
namespace Database\Seeders;
use App\Models\User;use Illuminate\Database\Seeder;use Illuminate\Support\Facades\Hash;
class DatabaseSeeder extends Seeder {public function run():void{User::updateOrCreate(['email'=>'admin@phonerepair.test'],['name'=>'ผู้ดูแลระบบ','phone'=>'0800000000','password'=>Hash::make('Admin1234!'),'role'=>'admin']);User::updateOrCreate(['email'=>'tech@phonerepair.test'],['name'=>'ช่างตัวอย่าง','phone'=>'0810000000','password'=>Hash::make('Tech1234!'),'role'=>'technician']);User::updateOrCreate(['email'=>'customer@phonerepair.test'],['name'=>'ลูกค้าตัวอย่าง','phone'=>'0820000000','password'=>Hash::make('User1234!'),'role'=>'customer']);}}
