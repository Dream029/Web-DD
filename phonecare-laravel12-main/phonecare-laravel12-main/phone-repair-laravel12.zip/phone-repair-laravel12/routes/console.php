<?php
use Illuminate\Support\Facades\Artisan;
Artisan::command('phonecare:about', function () { $this->info('PhoneCare - ระบบแจ้งซ่อมโทรศัพท์มือถือ'); })->purpose('Display PhoneCare project information');
