<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Relations\HasMany;
class User extends Authenticatable { use HasFactory, Notifiable; protected $fillable=['name','email','phone','password','role']; protected $hidden=['password','remember_token']; protected function casts(): array { return ['email_verified_at'=>'datetime','password'=>'hashed']; } public function repairRequests(): HasMany { return $this->hasMany(RepairRequest::class,'customer_id'); } public function assignedRepairs(): HasMany { return $this->hasMany(RepairRequest::class,'technician_id'); } }
