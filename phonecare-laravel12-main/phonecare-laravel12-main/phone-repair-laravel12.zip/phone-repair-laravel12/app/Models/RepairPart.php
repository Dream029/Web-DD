<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class RepairPart extends Model { protected $fillable=['repair_request_id','part_name','quantity','unit_price']; protected function casts(): array { return ['quantity'=>'integer','unit_price'=>'decimal:2']; } public function repairRequest(): BelongsTo { return $this->belongsTo(RepairRequest::class); } }
