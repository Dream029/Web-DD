<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
class RepairRequest extends Model { protected $fillable=['ticket_no','customer_id','technician_id','brand','model','imei','problem_description','accessories','status','diagnosis','labor_cost','parts_cost','received_at','completed_at']; protected function casts(): array { return ['labor_cost'=>'decimal:2','parts_cost'=>'decimal:2','received_at'=>'datetime','completed_at'=>'datetime']; } public function customer(): BelongsTo { return $this->belongsTo(User::class,'customer_id'); } public function technician(): BelongsTo { return $this->belongsTo(User::class,'technician_id'); } public function parts(): HasMany { return $this->hasMany(RepairPart::class); } public function getTotalCostAttribute(): float { return (float)$this->labor_cost+(float)$this->parts_cost; } }
