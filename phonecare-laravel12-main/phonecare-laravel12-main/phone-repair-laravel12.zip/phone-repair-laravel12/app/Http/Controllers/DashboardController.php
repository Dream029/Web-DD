<?php
namespace App\Http\Controllers;
use App\Models\RepairRequest;
use App\Models\User;
use App\Models\RepairPart;
use Illuminate\Http\Request;
class DashboardController extends Controller { public function index(Request $request){$user=$request->user();$query=RepairRequest::with(['customer','technician']);if($user->role==='customer')$query->where('customer_id',$user->id);elseif($user->role==='technician')$query->where('technician_id',$user->id);$repairs=(clone $query)->latest()->paginate(10);$stats=['total'=>(clone $query)->count(),'pending'=>(clone $query)->whereIn('status',['received','diagnosing','waiting_parts'])->count(),'repairing'=>(clone $query)->where('status','repairing')->count(),'completed'=>(clone $query)->whereIn('status',['completed','returned'])->count()];$users=$user->role==='admin'?User::orderBy('created_at','desc')->get():collect();$technicians=$user->role==='admin'?User::where('role','technician')->orderBy('name')->get():collect();$revenue=$user->role==='admin'?(float)RepairRequest::whereIn('status',['completed','returned'])->selectRaw('COALESCE(SUM(labor_cost + parts_cost),0) as total')->value('total'):0;return view('dashboard',compact('repairs','stats','users','technicians','revenue'));} }
