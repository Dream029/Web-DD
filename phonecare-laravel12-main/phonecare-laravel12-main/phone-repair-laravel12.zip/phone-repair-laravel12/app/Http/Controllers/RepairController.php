<?php
namespace App\Http\Controllers;
use App\Models\RepairRequest;
use App\Models\RepairPart;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;
class RepairController extends Controller {
 public function index(Request $request){$q=RepairRequest::with(['customer','technician'])->latest();if($request->user()->role==='customer')$q->where('customer_id',$request->user()->id);if($request->user()->role==='technician')$q->where('technician_id',$request->user()->id);if($request->filled('status'))$q->where('status',$request->string('status'));if($request->filled('ticket'))$q->where('ticket_no','like','%'.$request->string('ticket').'%');return view('repairs.index',['repairs'=>$q->paginate(12)->withQueryString()]);}
 public function create(){return view('repairs.create');}
 public function store(Request $request){$data=$request->validate(['brand'=>'required|string|max:80','model'=>'required|string|max:120','imei'=>'nullable|string|max:40','problem_description'=>'required|string|max:3000','accessories'=>'nullable|string|max:500']);$data['customer_id']=$request->user()->id;$data['ticket_no']='PR-'.now()->format('ymd').'-'.strtoupper(Str::random(5));$data['status']='received';$data['received_at']=now();$repair=RepairRequest::create($data);return redirect()->route('repairs.show',$repair)->with('success','แจ้งซ่อมเรียบร้อย เลขที่ใบรับซ่อม '.$repair->ticket_no);}
 public function show(Request $request, RepairRequest $repair){$this->authorizeRepair($request,$repair);$repair->load(['customer','technician','parts']);$technicians=User::where('role','technician')->orderBy('name')->get();return view('repairs.show',compact('repair','technicians'));}
 public function assign(Request $request,RepairRequest $repair){$data=$request->validate(['technician_id'=>'nullable|exists:users,id']);if($data['technician_id'] && !User::where('id',$data['technician_id'])->where('role','technician')->exists())return back()->withErrors(['technician_id'=>'บัญชีนี้ไม่ได้มีบทบาทช่าง']);$repair->update(['technician_id'=>$data['technician_id']]);return back()->with('success','มอบหมายช่างเรียบร้อย');}
 public function update(Request $request,RepairRequest $repair){$this->authorizeRepair($request,$repair);$data=$request->validate(['status'=>['required',Rule::in(['received','diagnosing','waiting_parts','repairing','completed','returned','cancelled'])],'diagnosis'=>'nullable|string|max:3000','labor_cost'=>'required|numeric|min:0|max:9999999','parts_cost'=>'required|numeric|min:0|max:9999999']);$data['completed_at']=in_array($data['status'],['completed','returned'])?($repair->completed_at??now()):null;$repair->update($data);return back()->with('success','อัปเดตสถานะและค่าใช้จ่ายเรียบร้อย');}
 public function addPart(Request $request,RepairRequest $repair){$data=$request->validate(['part_name'=>'required|string|max:150','quantity'=>'required|integer|min:1|max:10000','unit_price'=>'required|numeric|min:0|max:999999']);DB::transaction(function()use($repair,$data){$repair->parts()->create($data);$repair->update(['parts_cost'=>$repair->parts()->sum(DB::raw('quantity * unit_price'))]);});return back()->with('success','บันทึกอะไหล่เรียบร้อย');}
 public function destroy(Request $request,RepairRequest $repair){if($request->user()->role!=='admin')abort(403);$repair->delete();return redirect()->route('repairs.index')->with('success','ลบรายการแจ้งซ่อมแล้ว');}
 private function authorizeRepair(Request $request,RepairRequest $repair):void{$role=$request->user()->role;if($role==='customer' && $repair->customer_id!==$request->user()->id)abort(403);if($role==='technician' && $repair->technician_id!==$request->user()->id)abort(403);}
}
