<?php
namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
class AuthController extends Controller {
 public function showLogin(){ return view('auth.login'); }
 public function login(Request $request){ $credentials=$request->validate(['email'=>'required|email','password'=>'required|string']); if(Auth::attempt($credentials,$request->boolean('remember'))){$request->session()->regenerate();return redirect()->intended(route('dashboard'));} return back()->withErrors(['email'=>'อีเมลหรือรหัสผ่านไม่ถูกต้อง'])->onlyInput('email'); }
 public function showRegister(){return view('auth.register');}
 public function register(Request $request){$data=$request->validate(['name'=>'required|string|max:120','email'=>'required|email|max:255|unique:users,email','phone'=>'nullable|string|max:30','password'=>'required|string|min:8|confirmed']);$data['role']='customer';$user=User::create($data);Auth::login($user);$request->session()->regenerate();return redirect()->route('dashboard')->with('success','สมัครสมาชิกเรียบร้อยแล้ว');}
 public function logout(Request $request){Auth::logout();$request->session()->invalidate();$request->session()->regenerateToken();return redirect()->route('login');}
}
