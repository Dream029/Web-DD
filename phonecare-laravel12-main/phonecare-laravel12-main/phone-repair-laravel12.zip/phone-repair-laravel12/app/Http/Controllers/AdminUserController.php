<?php
namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
class AdminUserController extends Controller { public function index(){return view('admin.users',['users'=>User::orderBy('created_at','desc')->paginate(15)]);} public function store(Request $request){$data=$request->validate(['name'=>'required|string|max:120','email'=>'required|email|unique:users,email','phone'=>'nullable|string|max:30','role'=>['required',Rule::in(['admin','technician','customer'])],'password'=>'required|string|min:8']);$data['password']=Hash::make($data['password']);User::create($data);return back()->with('success','เพิ่มผู้ใช้เรียบร้อย');} public function update(Request $request,User $user){if($user->id===$request->user()->id && $request->input('role')!=='admin')return back()->withErrors(['role'=>'ไม่สามารถลดสิทธิ์บัญชีที่กำลังใช้งานได้']);$data=$request->validate(['name'=>'required|string|max:120','phone'=>'nullable|string|max:30','role'=>['required',Rule::in(['admin','technician','customer'])]]);$user->update($data);return back()->with('success','แก้ไขผู้ใช้เรียบร้อย');} public function destroy(Request $request,User $user){if($user->id===$request->user()->id)return back()->withErrors(['user'=>'ไม่สามารถลบบัญชีตัวเองได้']);$user->delete();return back()->with('success','ลบผู้ใช้เรียบร้อย');} }
