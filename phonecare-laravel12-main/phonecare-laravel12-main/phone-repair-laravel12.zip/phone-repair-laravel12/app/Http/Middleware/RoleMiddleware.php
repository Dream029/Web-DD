<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
class RoleMiddleware { public function handle(Request $request, Closure $next, string ...$roles): Response { if (!$request->user() || !in_array($request->user()->role, $roles, true)) { abort(403, 'คุณไม่มีสิทธิ์เข้าถึงหน้านี้'); } return $next($request); } }
